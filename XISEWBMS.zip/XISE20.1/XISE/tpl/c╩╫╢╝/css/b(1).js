!function(){var n={},t={};n.context=function(n,e){var i=arguments.length;if(i>1)t[n]=e;else if(1==i){if("object"!=typeof n)return t[n];for(var o in n)n.hasOwnProperty(o)&&(t[o]=n[o])}},"F"in window||(window.F=n)}();;
																																							
			F.context('user', {"isLogin":"0","stoken":"","name":"","id":"","wealth":"","gradeIndex":""});

							F.context('defaultQuery', '{"title":"","value":""}');
																			F.context('zhimaTagOpen', {
					'open': 1,
					'url': 'http://zhidao.baidu.com/zhima/',
					'text': '#֥�鿪��#'
				});