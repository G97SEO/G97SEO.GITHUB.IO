F.context('cmsRight', [
															
							{
					'url':'http://zhidao.baidu.com/s/book/index.html',
					'src':'http://img.baidu.com/img/iknow/sula01/zhongchouchushuQBbanner.jpg?t=1411639551'
				},																		
							{
					'url':'http://tieba.baidu.com/p/3299474933',
					'src':'http://img.baidu.com/img/iknow/270x1701.jpg?t=1411639551'
				},																		
							{
					'url':'http://lvyou.baidu.com/event/s/2014goldenweek/?fr=iknow',
					'src':'http://img.baidu.com/img/iknow/sula01/lvyouhuodongzhouruixue.png?t=1411639551'
				}							]);